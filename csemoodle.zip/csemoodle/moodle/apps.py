from django.apps import AppConfig


class MoodleConfig(AppConfig):
    name = 'moodle'
