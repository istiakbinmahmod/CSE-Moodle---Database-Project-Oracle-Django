import random
from django import template

register = template.Library()

@register.filter(name='randgen')
def randgen():
    return random.randint(0, 10000)