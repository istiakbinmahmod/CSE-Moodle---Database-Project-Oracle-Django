from django.shortcuts import render, redirect
import random
import os
import hashlib
import datetime
from django.http import HttpResponse,HttpResponseRedirect
from django.views import View
# from .models import people
from django.db import connection
from django import template
# Create your views here.
from .loginOrSignUp import loginOrSignup
from .loginOrSignUp.loginOrSignup import user_logout


def home(request):
    result = None
    print('home e asi')
    try:
        cur = connection.cursor()
        cur.execute("select * from course")
        result = cur.fetchall()
        cur.close()
    except:
        print('product fetch failed')
        return redirect('/homepage')
    print('aso')
    dict_res = []
    for r in result:
        course_id = r[0]
        session_id = r[1]
        course_title = r[2]
        credit_hour = r[3]
        #print(course_id)
        #print(session_id)
        #print(credit_hour)
        #print(course_title)
        row = {'course_id':course_id, 'session_id':session_id, 'course_title':course_title, 'credit_hour': credit_hour}
        dict_res.append(row)
    cur.close()
    return render(request, 'homepage.html', {'courses':dict_res})

def profileadmincreatecourses(request):
    try:
        usr = request.session['username']
    except:
        user_logout(request)
    if request.method == 'POST':
        courseid = request.POST.get('courseid')
        sessionid = request.POST.get('sessionid')
        coursetitle = request.POST.get('coursetitle')
        credithour = request.POST.get('credithour')
        sql = "INSERT INTO COURSE(COURSE_ID, SESSION_ID, COURSE_TITLE, CREDIT_HOUR) VALUES(%s, %s, %s, %s)"
        try:
            cur = connection.cursor()
            cur.execute(sql, [courseid, sessionid, coursetitle, credithour])
            connection.commit()
            cur.close()
            return redirect('/home/profile/admin/createcourses')
        except:
            return redirect('/home/profile/admin/createcourses/')
    name = request.session['username']
    return render(request, 'create_courses.html', {'name': name})

def profileadminassignstucourses(request):

    try:
        usr = request.session['username']
    except:
        user_logout(request)
    if request.method == 'POST':
        profileid = request.POST.get('profileid')
        courseid = request.POST.get('courseid')
        sessionid = request.POST.get('sessionid')
        sql = "INSERT INTO STUDENTCOURSERELATION(PROFILE_ID, COURSE_ID, SESSION_ID) VALUES(%s, %s, %s)"
        try:
            cur = connection.cursor()
            cur.execute(sql, [profileid, courseid, sessionid])
            connection.commit()
            cur.close()
            return redirect('/home/profile/admin/assignstucourses')
        except:
            return redirect('/home/profile/admin/assignstucourses/')
    name = request.session['username']
    return render(request, 'assign_students_to_course.html', {'name': name})

def profileadminassignteacourses(request):
    try:
        usr = request.session['username']
    except:
        user_logout(request)
    if request.method == 'POST':
        profileid = request.POST.get('profileid')
        courseid = request.POST.get('courseid')
        sessionid = request.POST.get('sessionid')
        sql = "INSERT INTO INSTRUCTORCOURSERELATION(PROFILE_ID, COURSE_ID, SESSION_ID) VALUES(%s, %s, %s)"
        try:
            cur = connection.cursor()
            cur.execute(sql, [profileid, courseid, sessionid])
            print(profileid)
            print(courseid)
            print(sessionid)
            connection.commit()
            cur.close()
            return redirect('/home/profile/admin/assignteacourses')
        except:
            return redirect('/home/profile/admin/assignteacourses/')
    name = request.session['username']
    return render(request, 'assign_teachers_to_course.html', {'name': name})


def studentcourse(request):
    sql = "select is_student, is_teacher from people where profile_id = %s"
    cur = connection.cursor()
    lol = request.session['userprofileid']
    print(lol)
    cur.execute(sql, [lol])
    result = cur.fetchall()
    isstu = 0
    dic_result = []
    for r in result:
        isstu = r[0]
        istea = r[1]
        row = {'isstu':isstu, 'istea':istea}
        dic_result.append(row)
    sql2 = "select material_id, file_type, file_path, course_id, session_id from course_materials where session_id = %s"
    print('sql e somossa nai')
    cur2 = connection.cursor()
    print('connection nite partese na')
    print(request.session['usercourseid'])
    print(request.session['usersessionid'])
    cur2.execute(sql2, [request.session['usersessionid']])
    #print('sql e disi', lol2)
    print('parameter nite partese na')
    result2 = cur2.fetchall()
    mat_result = []
    for r in result2:
        mate_id = r[0]
        file_ty = r[1]
        file_pa = r[2]
        cours_id = r[3]
        sessi_id = r[4]
        print(mate_id)
        print(file_ty)
        print(file_pa)
        print(cours_id)
        print(sessi_id)
        row = {'material_id': mate_id, 'file_type': file_ty, 'file_path': file_pa, 'course_id': cours_id,
               'session_id': sessi_id}
        mat_result.append(row)
    print('etokkhone to print korar kotha ')
    # connection.commit()
    cur2.close()
    sql3 = "select assignment_id, submission_link, file_path, course_id, session_id from assignment where session_id = %s"
    print('sql e somossa nai')
    cur3 = connection.cursor()
    print('connection nite partese na')
    print(request.session['usercourseid'])
    print(request.session['usersessionid'])
    cur3.execute(sql3, [request.session['usersessionid']])
    # print('sql e disi', lol2)
    print('parameter nite partese na')
    result3 = cur3.fetchall()
    ass_result = []
    for r in result3:
        ass_id = r[0]
        sub_link = r[1]
        file_pa = r[2]
        cours_id = r[3]
        sessi_id = r[4]
        print(ass_id)
        print(sub_link)
        print(file_pa)
        print(cours_id)
        print(sessi_id)
        row = {'assignment_id': ass_id, 'submission_link': sub_link, 'file_path': file_pa, 'course_id': cours_id,
               'session_id': sessi_id}
        ass_result.append(row)
    print('etokkhone to print korar kotha ')
    # connection.commit()
    cur3.close()
    return render(request, 'studentcourse.html', {'courseid':request.session['usercourseid'], 'sessionid':request.session['usersessionid'], 'usertype':dic_result, 'mat_result':mat_result, 'ass_result':ass_result})

def teachercourse(request):
    if request.method == 'POST':
        msg = request.POST.get('msg')
        if msg == 'uploadassignment':
            #course_id = request.session['usercourseid']
            #session_id = request.session['usersessionid']
            course_id = request.POST.get('course_id')
            session_id = request.POST.get('session_id')
            assignment_id = request.POST.get('assignment_id')
            ass_id = random.randint(0, 1000) + random.randint(0, 2000)
            sub_link = random.randint(0,1500) + random.randint(0, 3000)
            msg = request.POST.get('msg')
            print('msg print korbo')
            print(msg)
            print('kintu random korbo na')
            print('eta hoitese matid ' + str(ass_id))
            assignment = request.FILES['assignment']
            file_extension = os.path.splitext(assignment.name)[1]
            user_folder = 'static/assignments/'+ str(course_id) + str(session_id) + '/'
            if not os.path.exists(user_folder):
                os.mkdir(user_folder)
            # uploading image
            file_save_path = user_folder + 'assignment' + str(request.session['userprofileid']) + str(ass_id) + file_extension
            print(file_save_path)
            # img_save_path = user_folder + 'pro_pic'+img_extension
            file_url = 'profilepic/' + 'propic' + str(request.session['userprofileid']) + file_extension
            print(file_url)
            # request.session['propic'] = img_url
            # print(request.session['img_url'])
            with open(file_save_path, 'wb') as f:
                for chunk in assignment.chunks():
                    #print('writing in folder and database')
                    f.write(chunk)
            sql = "insert into assignment(assignment_id, submission_link, file_path, course_id, session_id) values(%s, %s, %s, %s, %s)"
            cur = connection.cursor()
            cur.execute(sql, [ass_id, sub_link, file_save_path, course_id, session_id])
            #connection.commit()
            cur.close()
            return redirect('/home/profile/teacher/course/')
            #profilepic = file_url
        else:
            # course_id = request.session['usercourseid']
            # session_id = request.session['usersessionid']
            course_id = request.POST.get('course_id')
            session_id = request.POST.get('session_id')
            material_id = request.POST.get('material_id')
            mat_id = random.randint(0, 1000) + random.randint(0, 2000)
            msg = request.POST.get('msg')
            print('msg print korbo')
            print(msg)
            print('kintu random korbo na')
            print('eta hoitese matid ' + str(mat_id))
            coursemat = request.FILES['coursemat']
            file_extension = os.path.splitext(coursemat.name)[1]
            user_folder = 'static/coursematerials/' + str(course_id) + str(session_id) + '/'
            if not os.path.exists(user_folder):
                os.mkdir(user_folder)
            # uploading image
            file_save_path = user_folder + 'coursematerials' + str(request.session['userprofileid']) + str(
                mat_id) + file_extension
            print(file_save_path)
            # img_save_path = user_folder + 'pro_pic'+img_extension
            file_url = 'profilepic/' + 'propic' + str(request.session['userprofileid']) + file_extension
            print(file_url)
            # request.session['propic'] = img_url
            # print(request.session['img_url'])
            with open(file_save_path, 'wb') as f:
                for chunk in coursemat.chunks():
                    # print('writing in folder and database')
                    f.write(chunk)
            sql = "insert into course_materials(material_id, file_type, file_path, course_id, session_id) values(%s, %s, %s, %s, %s)"
            cur = connection.cursor()
            cur.execute(sql, [mat_id, file_extension, file_save_path, course_id, session_id])
            # connection.commit()
            cur.close()
            return redirect('/home/profile/teacher/course/')
            # profilepic = file_url
    else:
        print(request.session['usersessionid'])
        lol2 = request.session['usersessionid']
        cur = connection.cursor()
        cur.execute("select name from people where profile_id = 1705074")
        res = cur.fetchall()
        print(res)
        cur = connection.cursor()
        lol = request.session['usercourseid']
        print(lol)
        sql = "select is_student, is_teacher from people where profile_id = %s"
        cur = connection.cursor()
        lol = request.session['userprofileid']
        print(lol)
        cur.execute(sql, [lol])
        result = cur.fetchall()
        print(result)
        isstu = 0
        istea = 0
        dic_result = []
        for r in result:
            isstu = r[0]
            istea = r[1]
            row = {'isstu': isstu, 'istea': istea}
            dic_result.append(row)
        print('sql ei somossa')
        sql2 = "select material_id, file_type, file_path, course_id, session_id from course_materials where session_id = %s"
        print('sql e somossa nai')
        cur2 = connection.cursor()
        print('connection nite partese na')
        print(request.session['usercourseid'])
        print(request.session['usersessionid'])
        cur2.execute(sql2, [lol2])
        print('sql e disi', lol2)
        print('parameter nite partese na')
        result2 = cur2.fetchall()
        mat_result = []
        for r in result2 :
            mate_id = r[0]
            file_ty = r[1]
            file_pa = r[2]
            cours_id = r[3]
            sessi_id = r[4]
            print(mate_id)
            print(file_ty)
            print(file_pa)
            print(cours_id)
            print(sessi_id)
            row = {'material_id':mate_id, 'file_type':file_ty, 'file_path': file_pa, 'course_id':cours_id, 'session_id': sessi_id}
            mat_result.append(row)
        print('etokkhone to print korar kotha ')
        #connection.commit()
        cur2.close()

        sql3 = "select assignment_id, submission_link, file_path, course_id, session_id from assignment where session_id = %s"
        print('sql e somossa nai')
        cur3 = connection.cursor()
        print('connection nite partese na')
        print(request.session['usercourseid'])
        print(request.session['usersessionid'])
        cur3.execute(sql3, [request.session['usersessionid']])
        print('sql e disi', lol2)
        print('parameter nite partese na')
        result3 = cur3.fetchall()
        ass_result = []
        for r in result3:
            ass_id = r[0]
            sub_link = r[1]
            file_pa = r[2]
            cours_id = r[3]
            sessi_id = r[4]
            print(ass_id)
            print(sub_link)
            print(file_pa)
            print(cours_id)
            print(sessi_id)
            row = {'assignment_id': ass_id, 'submission_link': sub_link, 'file_path': file_pa, 'course_id': cours_id,
                   'session_id': sessi_id}
            ass_result.append(row)

        return render(request, 'teachercourse.html',
                      {'courseid': request.session['usercourseid'], 'sessionid': request.session['usersessionid'],
                       'usertype': dic_result, 'userid':lol, 'mat_result':mat_result, 'ass_result':ass_result})